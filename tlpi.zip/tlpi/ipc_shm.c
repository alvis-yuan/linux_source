#include "ipc_shm.h"
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>

typedef struct _shm_ctx {
    int fd;
    size_t size;
    char *name;
    void* addr;
    struct _shm_ctx *next;
} shm_ctx_t;

static shm_ctx_t *shm_head = NULL;

static void register_shm_ctx(shm_ctx_t *ctx)
{
    if (ctx == NULL) {
        LogError("Invalid parameters: ctx=%p", ctx);
        return;
    }
    
    ctx->next = shm_head;
    shm_head = ctx;
}

static void unregister_shm_ctx(shm_ctx_t *ctx)
{
    if (ctx == NULL) {
        LogError("Invalid parameters: ctx=%p", ctx);
        return;
    }
    
    shm_ctx_t **prev = &shm_head;
    while (*prev != NULL) {
        if (*prev == ctx) {
            *prev = ctx->next;
            return;
        }
        prev = &(*prev)->next;
    }
    
    LogError("Context not found in list");
}

static shm_ctx_t *find_shm_ctx(void *addr)
{
    shm_ctx_t *ctx = shm_head;
    while (ctx != NULL) {
        if (ctx->addr == addr) {
            return ctx;
        }
        ctx = ctx->next;
    }
    return NULL;
}


void *shm_create(const char* name, size_t size)
{
    int fd = -1;
    void* addr = NULL;
    shm_ctx_t *ctx = NULL;
    
    if (name == NULL || size == 0) {
        LogError("Invalid parameters: name=%s, size=%zu", name, size);
        goto out;
    }

    ctx = calloc(1, sizeof(shm_ctx_t));
    if (ctx == NULL) {
        LogError("Failed to allocate memory for shm_ctx_t");
        goto out;
    }
    
    fd = shm_open(name, O_CREAT | O_EXCL | O_RDWR, 0644);
    if (fd != -1) {
        LogInfo("First process: creating shared memory");
        
        // 设置大小
        if (ftruncate(fd, size) == -1) {
            LogError("ftruncate failed: %s", strerror(errno));
            goto out;
        }       
    } else if (errno == EEXIST) {
        // 已经存在，直接打开
        LogInfo("Later process: opening existing shared memory");
        fd = shm_open(name, O_RDWR, 0644);
        if (fd == -1) {
            LogError("shm_open existing failed: %s", strerror(errno));
            goto out;
        }
    } else {
        // 其他错误
        LogError("shm_open failed: %s", strerror(errno));
        goto out;
    }

    // 初始化共享内存内容
    addr = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (addr == MAP_FAILED) {
        LogError("mmap failed: %s", strerror(errno));
        goto out;
    }
    memset(addr, 0, size); // 清零初始化 
    
    ctx->fd = fd;
    ctx->size = size;
    ctx->addr = addr;
    ctx->name = strdup(name);
    if (ctx->name == NULL) {
        LogError("Failed to duplicate name: %s", name);
        goto out;
    }
    
    register_shm_ctx(ctx);
    
    return addr;

out:
    if (addr != MAP_FAILED) {
        munmap(addr, size);
    }
    if (fd != -1) {
        close(fd);
    }
    if (ctx != NULL) {
        if (ctx->name != NULL) {
            free(ctx->name);
        }
        free(ctx);
    }   
    return NULL;
}

int shm_destroy(void* addr)
{
    shm_ctx_t* ctx = find_shm_ctx(addr);
    if (ctx == NULL) {
        LogError("Invalid parameters: addr=%p", addr);
        return -1;
    }

    unregister_shm_ctx(ctx);
    
    if (ctx->addr != MAP_FAILED) {
        munmap(ctx->addr, ctx->size);
    }

    if (ctx->fd != -1) {
        close(ctx->fd);
    }

    // 删除共享内存对象
    shm_unlink(ctx->name);

    if (ctx->name != NULL) {
        free(ctx->name);
    }
    free(ctx);
    
    return 0;
}

