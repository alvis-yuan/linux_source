#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include "thread.h"

/** 测试用例计数器 */
static int test_count = 0;
static int passed_count = 0;

#define MULTI_THREAD_DEADLOCK_TEST

/**
 * @brief 断言宏，用于测试验证
 */
#define TEST_ASSERT(condition, message) \
    do { \
        test_count++; \
        if (condition) { \
            printf("✓ TEST %d PASSED: %s\n", test_count, message); \
            passed_count++; \
        } else { \
            printf("✗ TEST %d FAILED: %s\n", test_count, message); \
        } \
    } while(0)

/**
 * @brief 测试用例1: 正常锁操作流程
 */
static void test_normal_lock_operations(void)
{
    printf("\n=== 测试1: 正常锁操作流程 ===\n");
    
    int ret;
    mutex_ctx_t *mutex = lock_init();
    
    // 初始化锁
    TEST_ASSERT(mutex != NULL, "锁初始化成功");
    
    // 获取锁
    ret = LOCK_ACQUIRE(mutex);
    TEST_ASSERT(ret == 0, "锁获取成功");
    
    // 查看锁状态
    lock_stat(mutex);
    
    // 释放锁
    ret = LOCK_RELEASE(mutex);
    TEST_ASSERT(ret == 0, "锁释放成功");
    
    // 销毁锁
    ret = lock_destroy(mutex);
    TEST_ASSERT(ret == 0, "锁销毁成功");
}


/**
 * @brief 测试用例4: 销毁还在持有的锁
 */
static void test_destroy_locked_mutex(void)
{
    printf("\n=== 测试2: 销毁还在持有的锁 ===\n");
    
    mutex_ctx_t *mutex = NULL;
    int ret = -1;
    
    // 初始化锁
    mutex = lock_init();
    TEST_ASSERT(mutex != NULL, "锁初始化成功");
    
    // 获取锁但不释放
    ret = LOCK_ACQUIRE(mutex);
    TEST_ASSERT(ret == 0, "锁获取成功");
    
    // 尝试销毁还在持有的锁
    ret = lock_destroy(mutex);
    TEST_ASSERT(ret == -1, "销毁持有的锁应失败");
    
    // 释放锁
    ret = LOCK_RELEASE(mutex);
    TEST_ASSERT(ret == 0, "锁释放成功");
    
    // 再次尝试销毁
    ret = lock_destroy(mutex);
    TEST_ASSERT(ret == 0, "锁销毁成功");
}

/**
 * @brief 测试用例5: 重入锁测试（递归锁）
 */
static void test_recursive_lock(void)
{
    printf("\n=== 测试3: 重入锁测试 ===\n");
    
    int ret = -1;
    mutex_ctx_t *mutex = lock_init();
    
    // 初始化锁
    TEST_ASSERT(mutex != NULL, "锁初始化成功");
    
    // 第一次获取锁
    ret = LOCK_ACQUIRE(mutex);
    TEST_ASSERT(ret == 0, "第一次锁获取成功");
    
#ifdef MUTEX_DEBUG
    // 第二次获取锁（重入）
    ret = LOCK_ACQUIRE(mutex);
    TEST_ASSERT(ret == -1, "第二次锁获取失败（重入）");
#endif
    
    // 查看锁状态
    lock_stat(mutex);
    
    // 第一次释放锁
    ret = LOCK_RELEASE(mutex);
    TEST_ASSERT(ret == 0, "第一次锁释放成功");
    
#ifdef MUTEX_DEBUG
    // 第二次释放锁
    ret = LOCK_RELEASE(mutex);
    TEST_ASSERT(ret == -1, "第二次锁释放失败");
#endif
    
    // 销毁锁
    ret = lock_destroy(mutex);
    TEST_ASSERT(ret == 0, "锁销毁成功");
}

/**
 * @brief 测试用例6: 多线程死锁场景
 */
typedef struct {
    mutex_ctx_t *mutex1;
    mutex_ctx_t *mutex2;
    int thread_id;
} thread_args_t;

static void* deadlock_thread_func(void *arg)
{
    thread_args_t *args = (thread_args_t *)arg;
    
#ifdef MULTI_THREAD_DEADLOCK_TEST
    if (args->thread_id == 1) {
        // 线程1: 先锁mutex1，再锁mutex2
        LOCK_ACQUIRE(args->mutex1);
        printf("线程1获取了mutex1\n");
        sleep(1);  // 让线程2有机会获取mutex2
        LOCK_ACQUIRE(args->mutex2);  // 这里会死锁
        printf("线程1获取了mutex2\n");
        LOCK_RELEASE(args->mutex2);
        LOCK_RELEASE(args->mutex1);
    } else {
        // 线程2: 先锁mutex2，再锁mutex1
        LOCK_ACQUIRE(args->mutex2);
        printf("线程2获取了mutex2\n");
        sleep(1);  // 让线程1有机会获取mutex1
        LOCK_ACQUIRE(args->mutex1);  // 这里会死锁
        printf("线程2获取了mutex1\n");
        LOCK_RELEASE(args->mutex1);
        LOCK_RELEASE(args->mutex2);
    }
#else
    LOCK_ACQUIRE(args->mutex1);
    printf("线程%d获取了mutex1\n", args->thread_id);
    sleep(1);  // 让线程2有机会获取mutex2
    LOCK_ACQUIRE(args->mutex2);  // 这里会死锁
    printf("线程%d获取了mutex2\n", args->thread_id);
    LOCK_RELEASE(args->mutex2);
    LOCK_RELEASE(args->mutex1);
#endif
    
    return NULL;
}

static void test_deadlock_scenario(void)
{
    printf("\n=== 测试4: 多线程死锁场景 ===\n");
    
    mutex_ctx_t *mutex1 = NULL;
    mutex_ctx_t *mutex2 = NULL;
    pthread_t thread1, thread2;
    thread_args_t args1, args2;
    int ret;
    
    // 初始化两个锁
    mutex1 = lock_init();
    TEST_ASSERT(mutex1 != NULL, "mutex1初始化成功");
    
    mutex2 = lock_init();
    TEST_ASSERT(mutex2 != NULL, "mutex2初始化成功");
    
    // 设置线程参数
    args1.mutex1 = mutex1;
    args1.mutex2 = mutex2;
    args1.thread_id = 1;
    
    args2.mutex1 = mutex1;
    args2.mutex2 = mutex2;
    args2.thread_id = 2;
    
    printf("创建两个线程模拟死锁场景（需要手动终止）\n");
    
    // 创建线程
    #if 0
    pthread_create(&thread1, NULL, deadlock_thread_func, &args1);
    pthread_create(&thread2, NULL, deadlock_thread_func, &args2);
    #else
    ret = THREAD_CREATE(&thread1, NULL, deadlock_thread_func, &args1);
    TEST_ASSERT(ret == 0, "线程1创建成功");
    
    ret = THREAD_CREATE(&thread2, NULL, deadlock_thread_func, &args2);
    TEST_ASSERT(ret == 0, "线程2创建成功");
    #endif
    
#ifdef MULTI_THREAD_DEADLOCK_TEST
    // 等待一段时间让死锁发生
    sleep(3);
    
    // 尝试join线程（会超时）
    printf("检测到可能的死锁，测试结束\n");
    
    // 强制终止线程（在实际测试中可能需要）
    pthread_cancel(thread1);
    pthread_cancel(thread2);
#else
    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);
#endif

    // 清理
    lock_destroy(mutex1);
    lock_destroy(mutex2);
}

/**
 * @brief 测试用例7: 参数有效性检查
 */
static void test_parameter_validation(void)
{
    printf("\n=== 测试5: 参数有效性检查 ===\n");
    
    int ret;
    
    // 测试NULL参数
    ret = lock_acquire(NULL, __FILE__, __func__, __LINE__);
    TEST_ASSERT(ret == -1, "NULL参数加锁应失败");
    
    ret = lock_release(NULL, __FILE__, __func__, __LINE__);
    TEST_ASSERT(ret == -1, "NULL参数解锁应失败");
    
    ret = lock_destroy(NULL);
    TEST_ASSERT(ret == -1, "NULL参数销毁应失败");
    
    lock_stat(NULL);  // 应该输出错误信息但不崩溃
}

/**
 * @brief 测试用例8: 锁状态查询
 */
static void test_lock_status(void)
{
    printf("\n=== 测试6: 锁状态查询 ===\n");
    
    mutex_ctx_t *mutex = NULL;
    int ret;
    
    // 初始化锁
    mutex = lock_init();
    TEST_ASSERT(mutex != NULL, "锁初始化成功");
    
    // 查看未锁定的状态
    printf("未锁定状态:\n");
    lock_stat(mutex);
    
    // 锁定后查看状态
    LOCK_ACQUIRE(mutex);
    printf("锁定后状态:\n");
    lock_stat(mutex);
    
    // 释放后查看状态
    LOCK_RELEASE(mutex);
    printf("释放后状态:\n");
    lock_stat(mutex);
    
    // 销毁锁
    ret = lock_destroy(mutex);
    TEST_ASSERT(ret == 0, "锁销毁成功");
}

/**
 * @brief 测试用例9: 加锁未初始化锁
 */
static void test_acquire_uninitialized_mutex(void)
{
    printf("\n=== 测试7: 加锁未初始化锁 ===\n");
    
    mutex_ctx_t *mutex = NULL;
    int ret;

    mutex = lock_init();
    
    // 尝试加锁未初始化的锁
    ret = lock_acquire(mutex, __FILE__, __func__, __LINE__);
    TEST_ASSERT(ret == -1, "未初始化锁加锁应失败");
}

/**
 * @brief 测试用例10: 解锁未初始化锁
 */
static void test_release_uninitialized_mutex(void)
{
    printf("\n=== 测试8: 解锁未初始化锁 ===\n");
    
    mutex_ctx_t *mutex = NULL;
    int ret;

    mutex = lock_init();
    
    // 尝试解锁未初始化的锁
    ret = lock_release(mutex, __FILE__, __func__, __LINE__);
    TEST_ASSERT(ret == -1, "未初始化锁解锁应失败");
}

/**
 * @brief 主测试函数
 */
int main(void)
{
    printf("开始线程操作接口测试...\n");
    printf("编译配置: MUTEX_DEBUG %s\n", 
#ifdef MUTEX_DEBUG
           "已启用"
#else
           "未启用"
#endif
    );
    
    // 运行所有测试用例
    #if 1
    test_normal_lock_operations();
    test_destroy_locked_mutex();
    test_recursive_lock();
    test_deadlock_scenario();
    test_parameter_validation();
    test_lock_status();
    #else
    test_acquire_uninitialized_mutex();
    test_release_uninitialized_mutex();
    #endif
    
    // 输出测试结果摘要
    printf("\n=== 测试结果摘要 ===\n");
    printf("总测试数: %d\n", test_count);
    printf("通过数: %d\n", passed_count);
    printf("失败数: %d\n", test_count - passed_count);
    printf("通过率: %.1f%%\n", (float)passed_count / test_count * 100);
    
    if (passed_count == test_count) {
        printf("🎉 所有测试通过！\n");
        return 0;
    } else {
        printf("❌ 有测试失败，请检查实现\n");
        return 1;
    }
}
