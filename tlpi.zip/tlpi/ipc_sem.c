#include "ipc_sem.h"
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/sem.h>

typedef struct _sem_ctx {
    sem_t *sem;
    char *name;
    struct _sem_ctx *next;
} sem_ctx_t;

static sem_ctx_t *sem_head = NULL;

static void register_sem_ctx(sem_ctx_t *ctx)
{
    if (ctx == NULL) {
        LogError("Invalid parameters: ctx=%p", ctx);
        return;
    }
    
    ctx->next = sem_head;
    sem_head = ctx;
}

static void unregister_sem_ctx(sem_ctx_t *ctx)
{
    if (ctx == NULL) {
        LogError("Invalid parameters: ctx=%p", ctx);
        return;
    }
    
    sem_ctx_t **prev = &sem_head;
    while (*prev != NULL) {
        if (*prev == ctx) {
            *prev = ctx->next;
            return;
        }
        prev = &(*prev)->next;
    }
    
    LogError("Context not found in list");
}

static sem_ctx_t *find_sem_ctx(sem_t *sem)
{
    sem_ctx_t *ctx = sem_head;
    while (ctx != NULL) {
        if (ctx->sem == sem) {
            return ctx;
        }
        ctx = ctx->next;
    }
    return NULL;
}

sem_t *named_sem_create(const char* name, int value)
{
    sem_t *sem = NULL;
    sem_ctx_t *ctx = NULL;
    
    if (name == NULL || value < 0) {
        LogError("Invalid parameters: name=%s, value=%d", name, value);
        goto out;
    }
    
    ctx = calloc(1, sizeof(sem_ctx_t));
    if (ctx == NULL) {
        LogError("Failed to allocate memory for sem_ctx_t");
        goto out;
    }
    
    sem = sem_open(name, O_CREAT | O_EXCL, 0644, value);
    if (sem != SEM_FAILED) {
        LogInfo("First process: creating semaphore");
    } else if (errno == EEXIST) {
        // 已经存在，直接打开
        LogInfo("Later process: opening existing semaphore");
        sem = sem_open(name, 0, 0644, 0);
        if (sem == SEM_FAILED) {
            LogError("sem_open existing failed: %s", strerror(errno));
            goto out;
        }
    } else {
        LogError("sem_open failed: %s", strerror(errno));
        goto out;
    }
    
    ctx->sem = sem;
    ctx->name = strdup(name);
    if (ctx->name == NULL) {
        LogError("Failed to duplicate name: %s", name);
        goto out;
    }

    register_sem_ctx(ctx);
    
    return sem;
    
out:
    if (ctx != NULL) {
        if (ctx->name != NULL) {
            if (ctx->sem != SEM_FAILED) {
                sem_close(ctx->sem);
            }
            if (ctx->name != NULL) {
                sem_unlink(ctx->name);
            }
            free(ctx->name);
        }
        free(ctx);
    }
    return NULL;
}

int named_sem_destroy(sem_t* sem)
{
    if (sem == NULL) {
        LogError("Invalid parameters: sem=%p", sem);
        return -1;
    }
    
    sem_ctx_t *ctx = find_sem_ctx(sem);
    if (ctx == NULL) {
        LogError("Semaphore context not found");
        return -1;
    }
    
    unregister_sem_ctx(ctx);

    if (ctx->sem != SEM_FAILED) {
        sem_close(ctx->sem);
    }
    
    if (ctx->name != NULL) {
        sem_unlink(ctx->name);
    }
    
    if (ctx->name != NULL) {
        free(ctx->name);
    }
    free(ctx);
    
    return 0;
}
