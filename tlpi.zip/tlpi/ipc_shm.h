#ifndef IPC_SHM_H
#define IPC_SHM_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/shm.h>

#define LogError(fmt, arg...) fprintf(stderr, "[%s-%d] " fmt "\n", __func__, __LINE__, ##arg)
#define LogInfo(fmt, arg...) fprintf(stderr, "[%s-%d] " fmt "\n", __func__, __LINE__, ##arg)


/**
 * @brief 创建共享内存
 * 
 * @param name 共享内存名称
 * @param size 共享内存大小
 * @return void* 成功返回地址指针，失败返回NULL
 */
void *shm_create(const char* name, size_t size);

/**
 * @brief 销毁共享内存
 * 
 * @param addr 共享内存地址指针
 * @return int 成功返回0，失败返回-1
 */
int shm_destroy(void* addr);


#endif // IPC_SHM_H