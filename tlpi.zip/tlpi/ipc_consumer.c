/**
 * @file example.c
 * @brief 消息队列封装使用示例
 */

#include "ipc.h"
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>


void consumer_example(void)
{
    mqd_t mq;
    char buffer[128];
    ssize_t bytes;
    bool is_alive = true;
    
    LogInfo("Starting consumer example");
    
    mq = mq_create("/test_queue", 10, 128, false);
    if (mq == -1) {
        LogError("Failed to create consumer queue");
        return;
    }

    // 使用epoll监听队列
    int epoll_fd = epoll_create1(0);
    if (epoll_fd < 0) {
        LogError("Failed to create epoll instance");
        mq_destroy(mq);
        return;
    }
    
    // 添加队列到epoll
    struct epoll_event event = {0};
    event.events = EPOLLIN;
    event.data.fd = mq;
    if (epoll_ctl(epoll_fd, EPOLL_CTL_ADD, mq, &event) < 0) {
        LogError("Failed to add queue to epoll");
        close(epoll_fd);
        mq_destroy(mq);
        return;
    }

    // 监听队列事件
    struct epoll_event events[1];
    int cnt = 0;
    while (cnt < 5) {
        int nfds = epoll_wait(epoll_fd, events, 1, 1000);
        if (nfds < 0) {
            LogError("epoll_wait failed: %s", strerror(errno));
            break;
        } else if (nfds == 0) {
            LogInfo("epoll_wait returned %d events, errno=%d", nfds, errno);
        }
        
        for (int i = 0; i < nfds; i++) {
            if (events[i].data.fd == mq) {
                bytes = mq_receive_msg(mq, buffer, sizeof(buffer));
                if (bytes > 0) {
                    LogInfo("Consumer received: %s", buffer);
                    cnt++;
                } else if (bytes == -1 && errno == ETIMEDOUT) {
                    LogInfo("No message received within timeout");
                    break;
                }
            }
        }
    }
    
    close(epoll_fd);
    mq_destroy(mq);
    LogInfo("Consumer example completed");
}

int main(void)
{
    consumer_example();

    return 0;
}