/**
 * @file example.c
 * @brief 消息队列封装使用示例
 */

#include "ipc.h"
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

void producer_example(void)
{
    mqd_t mq;
    char message[128];
    int i;
    
    LogInfo("Starting producer example");
    
    mq = mq_create("/test_queue", 10, 128, true);
    if (mq == -1) {
        LogError("Failed to create producer queue");
        return;
    }
    
    for (i = 0; i < 5; i++) {
        snprintf(message, sizeof(message), "Producer message %d", i);
        if (mq_send_msg(mq, message, strlen(message) + 1) != 0) {
            LogError("Failed to send message %d", i);
            break;
        }
        sleep(1);
    }
    
    mq_destroy(mq);
    LogInfo("Producer example completed");
}

int main(void)
{
    producer_example();
    
    return 0;
}