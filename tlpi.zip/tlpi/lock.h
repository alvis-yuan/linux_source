#ifndef LOCK_OPS_H
#define LOCK_OPS_H
#define _GNU_SOURCE
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

/** 调试信息开关 */
#define MUTEX_DEBUG

typedef struct _mutex_ctx mutex_ctx_t;

/**
 * @brief 初始化互斥锁
 * @param lck 互斥锁上下文指针
 * @return 成功返回互斥锁上下文指针，失败返回NULL
 */
mutex_ctx_t *lock_init(void);

/**
 * @brief 获取互斥锁
 * @param lck 互斥锁上下文指针
 * @return 成功返回0，失败返回-1
 */
int lock_acquire(mutex_ctx_t *lck, const char *file, const char *func, int line);

/**
 * @brief 释放互斥锁
 * @param lck 互斥锁上下文指针
 * @return 成功返回0，失败返回-1
 */
int lock_release(mutex_ctx_t *lck, const char *file, const char *func, int line);

/**
 * @brief 销毁互斥锁
 * @param lck 互斥锁上下文指针
 * @return 成功返回0，失败返回-1
 */
int lock_destroy(mutex_ctx_t *lck);

/**
 * @brief 打印锁的状态信息
 * @param lck 互斥锁上下文指针
 */
void lock_stat(mutex_ctx_t *lck);


#define LOCK_ACQUIRE(lck) lock_acquire(lck, __FILE__, __func__, __LINE__)
#define LOCK_RELEASE(lck) lock_release(lck, __FILE__, __func__, __LINE__)

#endif /* LOCK_OPS_H */
