#ifndef CONDVAR_H
#define CONDVAR_H

#include <stdbool.h>

typedef struct _cond_ctx cond_ctx_t;

struct cond_ops {
    bool (*check)(void *); /**< 条件判断回调，用于判断是否满足条件 */
    void *check_arg; /**< 条件判断回调函数参数 */
    void (*reset)(void *); /**< 条件重置回调，用于重置条件谓词 */
    void *reset_arg; /**< 条件重置回调函数参数 */
    void (*set)(void *); /**< 条件设置回调，用于设置条件谓词 */
};

/**
 * @brief 初始化条件变量上下文
 * 
 * @param name 条件变量名称
 * @param auto_reset 是否自动重置条件
 * @param ops 条件操作回调结构体
 * 
 * @return cond_ctx_t* 成功返回条件变量上下文指针，失败返回NULL
 */
cond_ctx_t *cond_init(const char *name, bool auto_reset, struct cond_ops ops);

/**
 * @brief 等待条件变量
 * 
 * @param ctx 条件变量上下文指针
 * @param timeout_ms 超时时间(毫秒)，-1表示无限等待, 默认值为-1
 * @param file 调用位置文件
 * @param func 调用位置函数
 * @param line 调用位置行号
 * @return int 成功返回0，超时返回ETIMEDOUT，错误返回其他错误码
 */
int cond_wait(cond_ctx_t *ctx, long timeout_ms, const char *file, const char *func, int line);
#define COND_WAIT(ctx) cond_wait(ctx, -1, __FILE__, __func__, __LINE__)
#define COND_WAIT_TIMEOUT(ctx, timeout_ms) cond_wait(ctx, timeout_ms, __FILE__, __func__, __LINE__)

/**
 * @brief 通知一个等待线程
 * 
 * @param ctx 条件变量上下文指针
 * @param set_arg 条件设置参数
 * @param file 调用位置文件
 * @param func 调用位置函数
 * @param line 调用位置行号
 * @return int 成功返回0，失败返回错误码
 */
int cond_signal(cond_ctx_t *ctx, void *set_arg, const char *file, const char *func, int line);
#define COND_SIGNAL(ctx, set_arg) cond_signal(ctx, set_arg, __FILE__, __func__, __LINE__)

/**
 * @brief 通知所有等待线程
 * 
 * @param ctx 条件变量上下文指针
 * @param set_arg 条件设置参数
 * @param file 调用位置文件
 * @param func 调用位置函数
 * @param line 调用位置行号
 * @return int 成功返回0，失败返回错误码
 */
int cond_broadcast(cond_ctx_t *ctx, void *set_arg, const char *file, const char *func, int line);
#define COND_BROADCAST(ctx, set_arg) cond_broadcast(ctx, set_arg, __FILE__, __func__, __LINE__)

/**
 * @brief 销毁条件变量
 * 
 * @param ctx 条件变量上下文指针
 * @param file 调用位置文件
 * @param func 调用位置函数
 * @param line 调用位置行号
 * @return int 成功返回0，失败返回错误码
 */
int cond_destroy(cond_ctx_t *ctx, const char *file, const char *func, int line);
#define COND_DESTROY(ctx) cond_destroy(ctx, __FILE__, __func__, __LINE__)

#endif /* CONDVAR_H */
