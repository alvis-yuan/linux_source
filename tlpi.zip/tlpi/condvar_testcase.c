#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include "condvar.h"

#define NUM_THREADS 5
#define TEST_TIMEOUT 1000

cond_ctx_t *ctx = NULL;

/* 测试数据结构 */
typedef struct {
    bool condition;
    int counter;
    int data;
} test_data_t;

/* 条件检查回调函数 */
bool check_condition(void *arg)
{
    test_data_t *data = (test_data_t *)arg;
    return data->condition;
}

/* 条件重置回调函数 */
void reset_condition(void *arg)
{
    test_data_t *data = (test_data_t *)arg;
    data->condition = false;
    printf("Condition reset to false\n");
}

/* 条件设置回调函数 */
void set_condition(void *arg)
{
    test_data_t *data = (test_data_t *)arg;
    data->condition = true;
    data->counter++;
    printf("Condition set to true, counter: %d\n", data->counter);
}

/* 带数据的条件设置回调函数 */
void set_condition_with_data(void *arg)
{
    test_data_t *data = (test_data_t *)arg;
    data->condition = true;
    data->counter++;
    data->data = 42;  // 设置一些测试数据
    printf("Condition set to true with data: %d, counter: %d\n", data->data, data->counter);
}

/* 工作线程函数 */
void* worker_thread(void *arg)
{
    test_data_t *data = (test_data_t *)arg;
    
    printf("Thread %ld: Waiting for condition...\n", pthread_self());
    
    int ret = COND_WAIT(ctx);
    if (ret == 0) {
        printf("Thread %ld: Condition satisfied! Data: %d\n", pthread_self(), data->data);
    } else if (ret == ETIMEDOUT) {
        printf("Thread %ld: Wait timeout\n", pthread_self());
    } else {
        printf("Thread %ld: Wait failed with error: %d-%s\n", pthread_self(), ret, strerror(ret));
    }
    
    return NULL;
}

/* 超时测试线程函数 */
void* timeout_worker_thread(void *arg)
{
    //cond_ctx_t *ctx = (cond_ctx_t *)arg;
    
    printf("Thread %ld: Waiting for condition with timeout %d ms...\n", 
           pthread_self(), TEST_TIMEOUT);
    
    int ret = COND_WAIT_TIMEOUT(ctx, TEST_TIMEOUT);
    if (ret == 0) {
        printf("Thread %ld: Condition satisfied!\n", pthread_self());
    } else if (ret == ETIMEDOUT) {
        printf("Thread %ld: Wait timeout as expected\n", pthread_self());
    } else {
        printf("Thread %ld: Wait failed with error: %d\n", pthread_self(), ret);
    }
    
    return NULL;
}

/* 测试1: 基本功能测试 - 单个信号 */
void test_basic_functionality(void)
{
    printf("\n=== Test 1: Basic Functionality ===\n");
    
    test_data_t data = {false, 0, 0};
    
    struct cond_ops ops = {
        .check = check_condition,
        .check_arg = &data,
        .reset = reset_condition,
        .reset_arg = &data,
        .set = set_condition_with_data
    };
    
    ctx = cond_init("basic_test", true, ops);
    if (ctx == NULL) {
        printf("Failed to initialize condition context\n");
        return;
    }
    
    pthread_t thread;
    pthread_create(&thread, NULL, worker_thread, &data);
    
    // 给线程时间开始等待
    sleep(1);
    
    printf("Main: Signaling one thread...\n");
    COND_SIGNAL(ctx, &data);
    
    pthread_join(thread, NULL);
    
    COND_DESTROY(ctx);
    printf("Test 1 completed\n");
}

/* 测试2: 广播测试 - 多个线程 */
void test_broadcast_functionality(void)
{
    printf("\n=== Test 2: Broadcast Functionality ===\n");
    
    test_data_t data = {false, 0, 0};
    
    struct cond_ops ops = {
        .check = check_condition,
        .check_arg = &data,
        .reset = reset_condition,
        .reset_arg = &data,
        .set = set_condition_with_data
    };
    
    ctx = cond_init("broadcast_test", false, ops);
    if (ctx == NULL) {
        printf("Failed to initialize condition context\n");
        return;
    }
    
    pthread_t threads[NUM_THREADS];
    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_create(&threads[i], NULL, worker_thread, &data);
    }
    
    // 给线程时间开始等待
    sleep(1);
    
    printf("Main: Broadcasting to all %d threads...\n", NUM_THREADS);
    COND_BROADCAST(ctx, &data);
    
    sleep(1);
    
    COND_DESTROY(ctx);

    // 通知多个线程，但是只有一个成功获取到锁
    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }
    printf("Test 2 completed\n");
}

/* 测试3: 超时测试 */
void test_timeout_functionality(void)
{
    printf("\n=== Test 3: Timeout Functionality ===\n");
    
    test_data_t data = {false, 0, 0};
    
    struct cond_ops ops = {
        .check = check_condition,
        .check_arg = &data,
        .reset = reset_condition,
        .reset_arg = &data,
        .set = set_condition_with_data
    };
    
    ctx = cond_init("timeout_test", true, ops);
    if (ctx == NULL) {
        printf("Failed to initialize condition context\n");
        return;
    }
    
    pthread_t thread;
    pthread_create(&thread, NULL, timeout_worker_thread, &data);
    
    // 给线程时间开始等待
    sleep(1);

    // 不发送信号，让线程超时
    pthread_join(thread, NULL);
    
    COND_DESTROY(ctx);
    printf("Test 3 completed\n");
}

/* 测试4: 关闭功能测试 */
void test_shutdown_functionality(void)
{
    printf("\n=== Test 4: Shutdown Functionality ===\n");
    
    test_data_t data = {false, 0, 0};
    
    struct cond_ops ops = {
        .check = check_condition,
        .check_arg = &data,
        .reset = reset_condition,
        .reset_arg = &data,
        .set = set_condition_with_data
    };
    
    ctx = cond_init("shutdown_test", true, ops);
    if (ctx == NULL) {
        printf("Failed to initialize condition context\n");
        return;
    }
    
    pthread_t threads[NUM_THREADS];
    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_create(&threads[i], NULL, worker_thread, &data);
    }
    
    // 给线程时间开始等待
    sleep(1);
    
    printf("Main: Shutting down condition context...\n");
    COND_DESTROY(ctx); // 该接口里面会关闭接口，通知在条件变量上等待的线程退出
    
    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
    }
    
    printf("Test 4 completed\n");
}

/* 测试5: 非自动重置测试 */
void test_non_auto_reset(void)
{
    printf("\n=== Test 5: Non-auto Reset Functionality ===\n");
    
    test_data_t data = {false, 0, 0};
    
    struct cond_ops ops = {
        .check = check_condition,
        .check_arg = &data,
        .reset = reset_condition,  // 即使是非自动重置，也需要提供reset函数
        .reset_arg = &data,
        .set = set_condition_with_data
    };
    
    // 创建非自动重置的条件变量
    ctx = cond_init("non_auto_reset_test", false, ops);
    if (ctx == NULL) {
        printf("Failed to initialize condition context\n");
        return;
    }
    
    pthread_t threads[2];
    for (int i = 0; i < 2; i++) {
        pthread_create(&threads[i], NULL, worker_thread, &data);
    }
    
    // 给线程时间开始等待
    sleep(1);
    
    printf("Main: Signaling first thread...\n");
    COND_SIGNAL(ctx, &data);
    
    sleep(1);
    
    printf("Main: Signaling second thread (condition should still be true)...\n");
    COND_SIGNAL(ctx, &data);
    
    COND_DESTROY(ctx);

    for (int i = 0; i < 2; i++) {
        pthread_join(threads[i], NULL);
    }
    
    printf("Test 5 completed\n");
}

/* 测试6: 错误参数测试 */
void test_error_cases(void)
{
    printf("\n=== Test 6: Error Cases ===\n");
    
    // 测试NULL参数
    int ret = cond_wait(NULL, -1, __FILE__, __func__, __LINE__);
    printf("cond_wait with NULL ctx returned: %d\n", ret);
    
    ret = cond_signal(NULL, NULL, __FILE__, __func__, __LINE__);
    printf("cond_signal with NULL ctx returned: %d\n", ret);
    
    // 测试无效的ops
    test_data_t data = {false, 0, 0};
    struct cond_ops invalid_ops = {
        .check = NULL,  // 必须的非NULL参数
        .check_arg = &data,
        .reset = reset_condition,
        .reset_arg = &data,
        .set = set_condition_with_data
    };
    
    cond_ctx_t *ctx = cond_init("invalid_test", true, invalid_ops);
    if (ctx == NULL) {
        printf("Correctly rejected invalid ops (check is NULL)\n");
    }
    
    printf("Test 6 completed\n");
}

struct {
    void (*test)(void);
    int num;
} tests[] = {
    {test_basic_functionality, 1},
    {test_broadcast_functionality, 2},
    {test_timeout_functionality, 3},
    {test_shutdown_functionality, 4},
    {test_non_auto_reset, 5},
    {test_error_cases, 6},
};

int main(int argc, char **argv)
{
    printf("Starting Condition Variable Tests...\n");
    
    if (argc > 1) {
        int test_num = atoi(argv[1]);
        for (int i = 0; i < sizeof(tests)/sizeof(tests[0]); i++) {
            if (tests[i].num == test_num) {
                tests[i].test();
                break;
            }
        }
    } else {
        for (int i = 0; i < sizeof(tests)/sizeof(tests[0]); i++) {
            tests[i].test();
        }
    }
    
    printf("\nAll tests completed!\n");
    return 0;
}