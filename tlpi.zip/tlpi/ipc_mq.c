/**
 * @file mq_wrapper.c
 * @brief POSIX消息队列安全封装实现
 */

#include "ipc_mq.h"
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <stdio.h>
#include <pthread.h>
#include <sys/types.h>
#include <signal.h>

/**
 * @brief 约定规则
1. 支持一个消费者（server），和多个生产者（client）通信, 避免多个消费者导致消息错乱
2. 可以支持请求响应，但是必须是一对一，并且定义好谁是server，谁是client
    2.1 如果只要一个client发送请求，server端可以直接回复，不需要创建私有队列。
    2.2 如果是多个client发送请求-响应，由client创建响应的私有专用队列，server端收到请求后，
        回复到这个队列，client端从这个队列接收回复。
3. 只有server进程才能创建和删除队列
4. server端起来的时候，如果存在队列，则删除；因为可能之前异常退出没有删除的
5. client因为没有创建队列的权利，所以必须server先启动，如果client先启动，open失败
6. 多消费者的场景都可以分解为多个队列，来支持单消费者，多个生产者。
 */

#define MAX_MSG_SIZE   1024
#define MQ_MAGIC 0xDEADBEEF


/** 消息队列上下文结构体
 * 这个结构体里面的成员，即使在同一个进程多个线程间调用，
 * 也只是创建接口的时候赋值，别的接口只是读取。所以不需要锁
 */
typedef struct _mq_ctx {
    uint32_t magic;     /**< 魔法数，用于验证上下文有效性 */
    int msg_num;        /**< 最大消息数量 */
    int msg_size;       /**< 单个消息最大大小 */
    bool server;        /**< 是否为server, 负责创建和删除队列 */
    mqd_t fd;           /**< 消息队列描述符 */
    char *name;         /**< 队列名称 */
    long msg_id;        /**< 消息ID */
} *mq_ctx_t;

typedef struct {
    pid_t pid;          /**< 请求进程ID，用于构造响应队列名称，client_<pid> */
    long msg_id;        /**< 消息ID */
    char data[0];       /**< 消息数据 */
} req_msg_t;

typedef struct {
    long msg_id;        /**< 消息ID */
    int status;         /**< 响应状态码 */
    char data[0];       /**< 消息数据 */
} rsp_msg_t;

/**
 * @brief 清空队列中的残留数据
 */
static void flush_queue(mqd_t mq_fd, int msg_size)
{
    int ret;
    char* buffer = NULL;
    struct mq_attr attr;
    
    if (mq_getattr(mq_fd, &attr) != 0) {
        LogError("Failed to get queue attributes: %s", strerror(errno));
        goto out;
    }

    if (attr.mq_curmsgs == 0) {
        LogInfo("Queue is empty, no need to flush");
        goto out;
    }
    
    buffer = malloc(msg_size);
    if (buffer == NULL) {
        LogError("Failed to allocate flush buffer");
        goto out;
    }
    
    // 设置为非阻塞模式，确保能清空所有消息
    long old_flag = attr.mq_flags;
    attr.mq_flags = O_NONBLOCK;
    if (mq_setattr(mq_fd, &attr, NULL) != 0) {
        LogError("Failed to set queue attributes: %s", strerror(errno));
        goto out;
    }
    
    for (int i = 0; i < attr.mq_curmsgs; i++) {
        ret = mq_receive(mq_fd, buffer, msg_size, NULL);
        if (ret > 0) {
            LogInfo("Flushed message, size: %d", ret);
        }
    }
    // 恢复之前的阻塞模式
    attr.mq_flags = old_flag;
    if (mq_setattr(mq_fd, &attr, NULL) != 0) {
        LogError("Failed to set queue attributes: %s", strerror(errno));
        goto out;
    }
    
    if (ret < 0 && errno != EAGAIN) {
        LogError("Error while flushing queue: %s", strerror(errno));
    }

out:
    if (buffer != NULL) {
        free(buffer);
    }
}

mq_ctx_t mq_create(const char* name, int msg_num, int msg_size, 
    bool is_server, bool block)
{
    int ret = -1;
    mq_ctx_t ctx = NULL;
    struct mq_attr attr;
    int flags;
    
    if (name == NULL || msg_num <= 0 || msg_size <= 0) {
        LogError("Invalid parameters: name=%p, msg_num=%d, msg_size=%d", 
                 name, msg_num, msg_size);
        goto error;
    }

    if (msg_size > MAX_MSG_SIZE) {
        LogError("Message size %d exceeds maximum %d", msg_size, MAX_MSG_SIZE);
        goto error;
    }
    
    ctx = calloc(1, sizeof(struct _mq_ctx));
    if (ctx == NULL) {
        LogError("Failed to allocate context memory");
        goto error;
    }
    
    ctx->magic = MQ_MAGIC;
    ctx->msg_num = msg_num;
    ctx->msg_size = msg_size;
    ctx->server = is_server;
    ctx->fd = (mqd_t)-1;
    ctx->msg_id = 0;
    ctx->name = strdup(name);
    if (ctx->name == NULL) {
        LogError("Failed to duplicate queue name");
        goto error;
    }
    
    /* 设置队列属性 */
    memset(&attr, 0, sizeof(attr));
    attr.mq_maxmsg = msg_num;
    attr.mq_msgsize = msg_size;
    attr.mq_flags = block ? 0 : O_NONBLOCK;

    if (is_server) {
        // 删除已存在的队列
        if (mq_unlink(name) != 0 && errno != ENOENT) {
            LogError("Failed to unlink existing queue %s: %s", 
                        name, strerror(errno));
            goto error;
        }
        flags = O_CREAT;
    }

    flags |= block ? 0 : O_NONBLOCK;

    if (duplex) {
        flags |= O_RDWR;
    } else {
        if (is_server) {
            flags |= O_RDONLY;
        } else {
            flags |= O_WRONLY;
        }
    }

    if (is_server) {
        ctx->fd = mq_open(name, flags, 0644, &attr);
    } else {
        ctx->fd = mq_open(name, flags);
    }
    if (ctx->fd == (mqd_t)-1) {
        LogError("mq_open failed: %s", strerror(errno));
        goto error;
    }
    
    LogInfo("Message queue created successfully: name=%s, server=%d", 
            name, is_server);
    
    return ctx;

error:
    if (ctx != NULL) {
        if (ctx->fd != (mqd_t)-1) {
            mq_close(ctx->fd);
        }
        if (ctx->name != NULL) {
            free(ctx->name);
        }
        free(ctx);
    }
    return NULL;
}

void mq_destroy(mq_ctx_t ctx)
{
    if (ctx == NULL || ctx->magic != MQ_MAGIC) {
        LogError("Invalid context pointer");
        return;
    }
    
    if (ctx->fd != (mqd_t)-1) {
        mq_close(ctx->fd);
        ctx->fd = (mqd_t)-1;
    }
    
    /* 只有创建者才能删除队列 */
    if (ctx->server) {
        if (mq_unlink(ctx->name) != 0 && errno != ENOENT) {
            LogError("Failed to unlink queue %s: %s", 
                        ctx->name, strerror(errno));
        } else {
            LogInfo("Queue unlinked: %s", ctx->name);
        }
    }
    
    free(ctx->name);
    free(ctx);
    
    LogInfo("Message queue context destroyed");
}

int mq_send_msg(mq_ctx_t ctx, const void* data, size_t len)
{
    int ret = -1;
    
    if (ctx == NULL || ctx->magic != MQ_MAGIC || data == NULL) {
        LogError("Invalid parameters: ctx=%p, data=%p", ctx, data);
        goto out;
    }
    
    if (len > (size_t)ctx->msg_size) {
        LogError("Message too large: %zu > %d", len, ctx->msg_size);
        goto out;
    }

    if (ctx->server) {
        LogError("Cannot send message in consumer mode");
        goto out;
    }
    
    if (ctx->fd == (mqd_t)-1) {
        LogError("Message queue is not available");
        goto out;
    }
    
    do {
        ret = mq_send(ctx->fd, data, len, 0);
    } while (ret == -1 && errno == EINTR);
    
    if (ret < 0) {
        if (errno != EAGAIN) {
            LogError("Failed to send message: %s", strerror(errno));
            goto out;
        } else {
            ret = -2; // 队列已满
        }
    }
    
    LogInfo("Message sent successfully: size=%zu", len);
    ret = 0;

out:
    return ret;
}

ssize_t mq_receive_msg(mq_ctx_t ctx, void* buffer, size_t buf_size)
{
    ssize_t ret = EINVAL;
    struct timespec timeout;
    struct mq_attr old_attr, new_attr;
    
    if (ctx == NULL || ctx->magic != MQ_MAGIC || buffer == NULL) {
        LogError("Invalid parameters: ctx=%p, buffer=%p", ctx, buffer);
        goto out;
    }
    
    if (ctx->fd == (mqd_t)-1) {
        LogError("Message queue is not available");
        goto out;
    }
    
    if (!ctx->server) {
        LogError("Cannot receive message in producer mode");
        goto out;
    }
    
    if (buf_size < (size_t)ctx->msg_size) {
        LogError("Buffer too small: %zu < %d", buf_size, ctx->msg_size);
        goto out;
    }
    
    if (ctx->fd == (mqd_t)-1) {
        LogError("Message queue is not available");
        goto out;
    }
    
    do {
        bytes = mq_receive(ctx->fd, (char*)buffer, buf_size, NULL);
    } while (ret == -1 && errno == EINTR);

    if (ret < 0) {
        if (errno != EAGAIN) {
            LogError("Failed to receive message: %s", strerror(errno));
        } else {
            ret = 0; // 无数据
        }
    } else {
        //LogInfo("Message received successfully: size=%zd", ret);
    }

out:
    return ret;
}

int mq_get_fd(mq_ctx_t ctx)
{
    if (ctx == NULL || ctx->magic != MQ_MAGIC) return -1;
    return ctx->fd;
}

int mq_req_msg(mq_ctx_t ctx, const void* req, size_t req_len, 
               void* resp, size_t *resp_len)
{
    int ret = -1;
    static __thread char resp_buf[MQ_MAX_MSG_SIZE + sizeof(rsp_msg_t)] = {0};
    static __thread char req_buf[MQ_MAX_MSG_SIZE + sizeof(req_msg_t)] = {0};
    struct req_msg_t *req_msg = (struct req_msg_t *)req_buf;
    struct rsp_msg_t *rsp_msg = (struct rsp_msg_t *)resp_buf;
    
    if (ctx == NULL || ctx->magic != MQ_MAGIC || req == NULL || resp == NULL) {
        LogError("Invalid parameters: ctx=%p, req=%p, resp=%p", ctx, req, resp);
        goto out;
    }
    
    if (req_len > (size_t)ctx->msg_size || req_len > MQ_MAX_MSG_SIZE - sizeof(req_msg_t)) {
        LogError("Request message too large: %zu > %d", req_len, ctx->msg_size);
        goto out;
    }
    
    if (resp_len < (size_t)ctx->msg_size) {
        LogError("Response buffer too small: %zu < %d", resp_len, ctx->msg_size);
        goto out;
    }

    req_msg->pid = getpid();
    memcpy(req_msg->data, req, req_len);
    req_msg->msg_id = ctx->msg_id++;
    
    ret = mq_send_msg(ctx, req, req_len);
    if (ret < 0) {
        LogError("Failed to send request message");
        goto out;
    }
    
    // 创建自己的响应队列
    char resp_name[MQ_NAME_MAX];
    struct mq_attr attr;
    attr.mq_maxmsg = 1;
    attr.mq_msgsize = ctx->msg_size + sizeof(rsp_msg_t);

    snprintf(resp_name, sizeof(resp_name), "client_%d", ctx->msg_id);
    mq_unlink(resp_name);

    int resp_fd = mq_open(resp_name, O_RDONLY | O_CREAT, 0644, &attr);
    if (resp_fd == (mqd_t)-1) {
        LogError("Failed to create response queue: %s", strerror(errno));
        goto out;
    }
    
    ret = mq_receive(resp_fd, resp_buf, sizeof(resp_buf), NULL);
    if (ret < 0) {
        LogError("Failed to receive response message");
        goto out;
    }

    // 检查响应消息的ID是否匹配
    if (rsp_msg->msg_id != req_msg->msg_id) {
        LogError("Response message ID mismatch: %ld != %ld", rsp_msg->msg_id, req_msg->msg_id);
        goto out;
    }
    
    memcpy(resp, rsp_msg->data, rsp_msg->len);
    *resp_len = rsp_msg->len;
    
    ret = 0;
    LogInfo("Request message processed successfully");
}