/**
 * @file thread_ops.h
 * @brief 线程操作接口头文件
 */

#ifndef THREAD_OPS_H
#define THREAD_OPS_H

#define _GNU_SOURCE
#include <pthread.h>
#include <string.h>
#include <errno.h>
#include <stdbool.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <stdio.h>
#include <sys/types.h>
#include <stdlib.h>

/**
 * @brief 创建线程
 * 
 * @param thread 线程ID指针
 * @param attr 线程属性指针
 * @param start_routine 线程启动函数指针
 * @param arg 线程启动函数参数
 * @param name 线程名
 * @param detached 是否为分离线程
 * @return 成功返回0，失败返回错误码
 */
int thread_create(pthread_t *thread, const pthread_attr_t *attr,
                  void *(*start_routine)(void *), void *arg, const char *name, bool detached);
#define THREAD_CREATE_DETACHED(thread, attr, start_routine, arg) \
    thread_create(thread, attr, start_routine, arg, #start_routine, true)
#define THREAD_CREATE(thread, attr, start_routine, arg) \
    thread_create(thread, attr, start_routine, arg, #start_routine, false)
#endif /* THREAD_OPS_H */