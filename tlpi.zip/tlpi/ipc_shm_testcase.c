#include "ipc_shm.h"
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>

// 在共享内存中存储的数据结构
struct shared_data {
    int counter;
    char message[128];
    pid_t last_process;
};

/**
 * 生产者进程 - 创建共享内存并初始化数据
 */
void producer_process() {
    LogInfo("=== Producer Process (PID: %d) ===\n", getpid());
    
    // 创建共享内存
    struct shared_data* data = (struct shared_data*)shm_create("/demo_shared_memory", 
                                                              sizeof(struct shared_data));
    if (!data) {
        LogError("Producer: Failed to create shared memory");
        return;
    }
    
    LogInfo("Producer: Shared memory created at %p", data);
    
    // 初始化数据
    data->counter = 0;
    strcpy(data->message, "Hello from producer");
    data->last_process = getpid();
    
    LogInfo("Producer: Initialized data - counter=%d, message='%s', last_pid=%d",
           data->counter, data->message, data->last_process);
    
    // 模拟工作 - 更新数据
    for (int i = 1; i <= 3; i++) {
        //sleep(2);
        LogInfo("Producer: Press Enter to continue...");
        getchar();
        data->counter = i;
        data->last_process = getpid();
        LogInfo("Producer: Updated - counter=%d, last_pid=%d", data->counter, data->last_process);
    }
    
    LogInfo("Producer: Work completed. Press Enter to destroy shared memory...");
    getchar();
    
    // 销毁共享内存
    if (shm_destroy(data) == 0) {
        LogInfo("Producer: Shared memory destroyed successfully");
    } else {
        LogError("Producer: Failed to destroy shared memory");
    }
}

/**
 * 消费者进程 - 使用已存在的共享内存
 */
void consumer_process() {
    LogInfo("=== Consumer Process (PID: %d) ===\n", getpid());
    
    // 打开已存在的共享内存
    struct shared_data* data = (struct shared_data*)shm_create("/demo_shared_memory", 
                                                              sizeof(struct shared_data));
    if (!data) {
        LogError("Consumer: Failed to open shared memory (maybe producer hasn't started?)");
        return;
    }
    
    LogInfo("Consumer: Shared memory opened at %p", data);
    
    // 读取并显示当前数据
    LogInfo("Consumer: Current data - counter=%d, message='%s', last_pid=%d",
           data->counter, data->message, data->last_process);
    
    for (int i = 0; i < 4; i++) {
        // 等待生产者更新数据
        LogInfo("Consumer: Current data - counter=%d, message='%s', last_pid=%d",
           data->counter, data->message, data->last_process);
        LogInfo("Consumer: Press Enter to continue...");
        getchar();
    }
    // 监控数据变化
    int last_counter = data->counter;
    for (int i = 0; i < 5; i++) {
        sleep(1);
        
        if (data->counter != last_counter) {
            LogInfo("Consumer: Data changed - counter=%d, message='%s', last_pid=%d",
                   data->counter, data->message, data->last_process);
            last_counter = data->counter;
        }
        
        // 消费者也可以更新数据
        if (i == 2) {
            strcpy(data->message, "Modified by consumer");
            data->last_process = getpid();
            LogInfo("Consumer: Updated message");
        }
    }
    
    LogInfo("Consumer: Monitoring completed. Press Enter to exit...");
    getchar();
    
    // 销毁共享内存引用（不会unlink，因为不是创建者）
    if (shm_destroy(data) == 0) {
        LogInfo("Consumer: Shared memory reference released");
    } else {
        LogError("Consumer: Failed to release shared memory reference");
    }
}

/**
 * 多进程测试 - 一个生产者和多个消费者
 */
void multi_process_test() {
    LogInfo("=== Multi-Process Test ===");
    
    pid_t producer_pid = fork();
    if (producer_pid == 0) {
        // 子进程1 - 生产者
        producer_process();
        exit(0);
    }
    
    sleep(1); // 给生产者一点时间启动
    
    // 创建多个消费者进程
    for (int i = 0; i < 2; i++) {
        pid_t consumer_pid = fork();
        if (consumer_pid == 0) {
            // 子进程 - 消费者
            LogInfo("--- Consumer %d ---", i + 1);
            consumer_process();
            exit(0);
        }
        sleep(1); // 错开消费者启动时间
    }
    
    // 父进程等待所有子进程结束
    for (int i = 0; i < 3; i++) {
        wait(NULL);
    }
    
    LogInfo("Multi-process test completed");
}

/**
 * 单进程测试 - 创建、使用、销毁共享内存
 */
void single_process_test() {
    LogInfo("=== Single Process Test ===");
    
    // 创建共享内存
    struct shared_data* data = (struct shared_data*)shm_create("/test_single_process", 
                                                              sizeof(struct shared_data));
    if (!data) {
        LogError("Single process: Failed to create shared memory");
        return;
    }
    
    LogInfo("Single process: Shared memory created at %p", data);
    
    // 使用共享内存
    data->counter = 100;
    strcpy(data->message, "Single process test");
    data->last_process = getpid();
    
    LogInfo("Single process: Written data - counter=%d, message='%s'",
           data->counter, data->message);
    
    // 验证数据读取
    LogInfo("Single process: Reading back - counter=%d, message='%s'",
           data->counter, data->message);
    
    // 验证数据读取
    LogInfo("Single process: Reading back - counter=%d, message='%s'",
           data->counter, data->message);
    
    // 销毁共享内存
    if (shm_destroy(data) == 0) {
        LogInfo("Single process: Shared memory destroyed successfully");
    } else {
        LogError("Single process: Failed to destroy shared memory");
    }
    
    LogInfo("Single process test completed");
}

/**
 * 错误处理测试
 */
void error_handling_test() {
    LogInfo("=== Error Handling Test ===");
    
    // 测试1: 无效参数
    LogInfo("Test 1: Invalid parameters");
    void* result = shm_create(NULL, 1024);
    if (result == NULL) {
        LogInfo("✓ Correctly rejected NULL name");
    }
    
    result = shm_create("/test_error", 0);
    if (result == NULL) {
        LogInfo("✓ Correctly rejected zero size");
    }
    
    // 测试2: 重复创建
    LogInfo("Test 2: Duplicate creation");
    void* shm1 = shm_create("/test_duplicate", 1024);
    if (shm1) {
        void* shm2 = shm_create("/test_duplicate", 1024);
        if (shm2) {
            LogInfo("✓ Second creation succeeded (opened existing)");
            
            // 验证两个指针指向相同数据
            struct shared_data* data1 = (struct shared_data*)shm1;
            struct shared_data* data2 = (struct shared_data*)shm2;
            
            data1->counter = 999;
            if (data2->counter == 999) {
                LogInfo("✓ Both pointers access the same shared memory");
            }
            
            shm_destroy(shm2);
        }
        shm_destroy(shm1);
    }
    
    // 测试3: 无效销毁
    LogInfo("Test 3: Invalid destroy");
    int destroy_result = shm_destroy((void*)0x12345678); // 无效地址
    if (destroy_result == -1) {
        LogInfo("✓ Correctly rejected invalid address");
    }
    
    LogInfo("Error handling test completed");
}

int main(int argc, char* argv[]) {
    LogInfo("Shared Memory IPC Example");
    LogInfo("Usage: %s [producer|consumer|multi|single|error]", argv[0]);
    
    if (argc > 1) {
        if (strcmp(argv[1], "producer") == 0) {
            producer_process();
        } else if (strcmp(argv[1], "consumer") == 0) {
            consumer_process();
        } else if (strcmp(argv[1], "multi") == 0) {
            multi_process_test();
        } else if (strcmp(argv[1], "single") == 0) {
            single_process_test();
        } else if (strcmp(argv[1], "error") == 0) {
            error_handling_test();
        } else {
            printf("Unknown command: %s\n", argv[1]);
            return 1;
        }
    } else {
        // 默认运行单进程测试
        single_process_test();
    }
    
    return 0;
}