/**
 * @file mq_wrapper.h
 * @brief POSIX消息队列安全封装接口
 * @author System Developer
 * @version 1.0
 * @date 2024-01-01
 */

#ifndef MQ_WRAPPER_H
#define MQ_WRAPPER_H

#include <stdbool.h>
#include <mqueue.h>
#include <sys/epoll.h>

/** 日志定义 */
#define LogError(fmt, arg...) fprintf(stderr, "[%s-%d] " fmt "\n", __func__, __LINE__, ##arg)
#define LogInfo(fmt, arg...) fprintf(stderr, "[%s-%d] " fmt "\n", __func__, __LINE__, ##arg)

typedef struct _mq_ctx *mq_ctx_t;
/**
 * @brief 创建或打开消息队列
 * 
 * @param name 队列基础名称
 * @param msg_num 最大消息数量
 * @param msg_size 单个消息最大大小
 * @param is_producer 是否为生产者模式
 * @return mq_ctx_t 成功返回上下文指针，失败返回NULL
 */
mq_ctx_t mq_create(const char* name, int msg_num, int msg_size, bool is_producer);

/**
 * @brief 销毁消息队列并释放资源
 * 
 * @param ctx 消息队列上下文指针
 */
void mq_destroy(mq_ctx_t ctx);

/**
 * @brief 发送消息到队列
 * 
 * @param ctx 消息队列上下文指针
 * @param data 消息数据指针
 * @param len 消息数据长度
 * @return int 成功返回0，失败返回-1
 */
int mq_send_msg(mq_ctx_t ctx, const void* data, size_t len);

/**
 * @brief 接收消息（支持超时）
 * 
 * @param ctx 消息队列上下文指针
 * @param buffer 接收缓冲区指针
 * @param buf_size 缓冲区大小
 * @return ssize_t 成功返回接收到的字节数，失败返回-1
 */
ssize_t mq_receive_msg(mq_ctx_t ctx, void* buffer, size_t buf_size);

/**
 * @brief 获取底层的文件描述符
 * 用于 epoll, select, poll 等
 * 
 * @param ctx 消息队列上下文指针
 * @return int 成功返回文件描述符，失败返回-1
 */
int mq_get_fd(mq_ctx_t ctx);

#endif /* MQ_WRAPPER_H */