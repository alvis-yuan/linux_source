#include "thread.h"
#include <signal.h>

#define LogError(fmt, arg...) fprintf(stderr, "[%s-%d] " fmt "\n", __func__, __LINE__, ##arg)
#define LogInfo(fmt, arg...) fprintf(stderr, "[%s-%d] " fmt "\n", __func__, __LINE__, ##arg)


typedef struct _thread_arg {
    void *(*start_routine)(void *); /**< 线程函数指针 */
    void *arg;                      /**< 线程函数参数 */
    const char *name;               /**< 线程名 */
    pthread_cond_t cond;            /**< 用于等待线程启动完成的条件变量 */
    pthread_mutex_t mutex;          /**< 用于保护started变量的互斥锁 */
    bool started;                   /**< 线程是否启动完成 */
    bool detached;                  /**< 线程是否为分离线程 */
} thread_arg_t;

typedef struct _thread_info {
    pthread_t pid;                  /**< 线程ID */
    char name[16];               /**< 线程名 */
    long tid;                    /**< 线程tid */
    struct timespec start_time;     /**< 线程启动时间 */
    struct timespec end_time;       /**< 线程结束时间 */
    int exit_code;                  /**< 线程退出码 */
    struct _thread_info *next;      /**< 下一个线程信息节点 */
} thread_info_t;

static thread_info_t *thread_info_head = NULL;

/**
 * @brief 初始化异常信号处理
 */
static pthread_once_t once_control = PTHREAD_ONCE_INIT;

static int time2str(char *buf, size_t size, struct timespec ts)
{
    return strftime(buf, size, "%Y-%m-%d %H:%M:%S", localtime(&ts.tv_sec));
}

static int register_thread_info(void)
{
    thread_info_t *thread_info = calloc(1, sizeof(thread_info_t));
    if (thread_info == NULL) {
        LogError("Failed to malloc thread_info");
        return -1;
    }

    thread_info->pid = pthread_self();
    thread_info->tid = syscall(SYS_gettid);
    pthread_getname_np(thread_info->pid, thread_info->name, sizeof(thread_info->name));
    clock_gettime(CLOCK_REALTIME, &thread_info->start_time);
    char start_time_str[32];
    time2str(start_time_str, sizeof(start_time_str), thread_info->start_time);
    LogInfo("Name: %s, TID: %ld, start time: %s", thread_info->name, thread_info->tid, start_time_str);
    
    if (thread_info_head == NULL) {
        thread_info_head = thread_info;
    } else {
        thread_info_t *current = thread_info_head;
        while (current->next != NULL) {
            current = current->next;
        }
        current->next = thread_info;
    }

    return 0;
}

static void dump_thread_info(pthread_t pid)
{
    thread_info_t *current = thread_info_head;
    while (current) {
        if (pthread_equal(current->pid, pid)) {
            // 计算总共运行时间
            int run_time = current->end_time.tv_sec - current->start_time.tv_sec;
            LogInfo("Thread ID: %ld, Name: %s, TID: %ld, Start Time: %ld, End Time: %ld, Exit Code: %d, Run Time: %d",
            current->pid, current->name, current->tid,
            current->start_time.tv_sec, current->end_time.tv_sec, current->exit_code, run_time);
            break;
        }
    }
}

static void unregister_thread_info(void)
{
    if (thread_info_head == NULL) {
        return;
    }

    thread_info_t *current = thread_info_head;
    while (current != NULL) {
        if (pthread_equal(current->pid, pthread_self())) {
            break;
        }
        current = current->next;
    }

    if (current == NULL) {
        LogError("Thread ID %ld not found in thread info list", pthread_self());
        return;
    }

    // 记录线程结束时间和退出码
    clock_gettime(CLOCK_REALTIME, &current->end_time);
    char end_time_str[32];
    time2str(end_time_str, sizeof(end_time_str), current->end_time);
    LogInfo("name: %s, TID: %ld, end time: %s, span: %ld", current->name, current->tid, end_time_str,
         current->end_time.tv_sec - current->start_time.tv_sec);
    current->exit_code = 0;

    if (thread_info_head->pid == current->pid) {
        thread_info_t *temp = thread_info_head;
        thread_info_head = thread_info_head->next;
        free(temp);
        return;
    }
    
    current = thread_info_head;
    while (current->next != NULL) {
        if (pthread_equal(current->next->pid, current->pid)) {
            thread_info_t *temp = current->next;
            current->next = temp->next;
            free(temp);
            return;
        }
        current = current->next;
    }
}

static void async_crash_handler(int signum, siginfo_t *info, void *context)
{
    // 立即禁用所有信号处理，避免递归崩溃
    struct sigaction sa;
    sa.sa_handler = SIG_DFL; // 如果再次触发信号：直接终止进程
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;
    
    sigaction(SIGSEGV, &sa, NULL);
    sigaction(SIGABRT, &sa, NULL);
    sigaction(SIGBUS, &sa, NULL);
    sigaction(SIGILL, &sa, NULL);
    sigaction(SIGFPE, &sa, NULL);

    LogError("TID: %ld, crash signal %d received, address: %p", 
        syscall(SYS_gettid), signum, info->si_addr);
    thread_info_t *current = thread_info_head;
    while (current != NULL) {
        if (pthread_equal(current->pid, pthread_self())) {
            break;
        }
        current = current->next;
    }

    if (current == NULL) {
        LogError("Thread ID %ld not found in thread info list", pthread_self());
        return;
    }

    // 记录线程结束时间和退出码
    clock_gettime(CLOCK_REALTIME, &current->end_time);
    char end_time_str[32];
    time2str(end_time_str, sizeof(end_time_str), current->end_time);
    LogInfo("name: %s, TID: %ld, end time: %s, span: %ld", current->name, current->tid, end_time_str,
         current->end_time.tv_sec - current->start_time.tv_sec);

    _exit(1);
}

static void setup_signal_handler(void)
{
    struct sigaction sa;
    sa.sa_sigaction = async_crash_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_SIGINFO | SA_ONSTACK | SA_RESETHAND;
    
    // 注册崩溃信号
    sigaction(SIGSEGV, &sa, NULL);
    sigaction(SIGABRT, &sa, NULL);
    sigaction(SIGBUS, &sa, NULL);
    sigaction(SIGILL, &sa, NULL);
    sigaction(SIGFPE, &sa, NULL);
}

/**
 * @brief 线程启动包装函数
 */
static void* _start_routine(void *arg)
{
    thread_arg_t *thread_arg = (thread_arg_t *)arg;
    void *(*start_routine)(void *) = thread_arg->start_routine;
    void *_arg = thread_arg->arg;
    
    if (start_routine == NULL) {
        LogError("start_routine is NULL");
        free(thread_arg);
        return NULL;
    }

    // 设置线程名字为函数名: 前8个字符+tid
    char thread_name[16];
    snprintf(thread_name, sizeof(thread_name), "%.8s_%ld", thread_arg->name, syscall(SYS_gettid));
    pthread_setname_np(pthread_self(), thread_name);

    register_thread_info();

    // 如果线程为分离线程，设置分离属性
    if (thread_arg->detached) {
        int ret = pthread_detach(pthread_self());
        if (ret != 0) {
            LogError("Failed to detach thread: %s", strerror(ret));
        }
    }

    // 设置线程启动完成标志
    pthread_mutex_lock(&thread_arg->mutex);
    thread_arg->started = true;
    pthread_cond_signal(&thread_arg->cond);
    pthread_mutex_unlock(&thread_arg->mutex);
    
    // 调用用户线程函数
    start_routine(_arg);
    
    unregister_thread_info();
    return NULL;
}

/**
 * @brief 创建线程
 */
int thread_create(pthread_t *thread, const pthread_attr_t *attr,
                  void *(*start_routine)(void *), void *arg, const char *name, bool detached)
{
    int ret = -1;
    thread_arg_t *thread_arg = NULL;
    
    if (thread == NULL) {
        LogError("Invalid parameter: thread is NULL");
        return EINVAL;
    }
    
    if (start_routine == NULL) {
        LogError("Invalid parameter: start_routine is NULL");
        return EINVAL;
    }
    
    thread_arg = malloc(sizeof(thread_arg_t));
    if (thread_arg == NULL) {
        LogError("Failed to allocate memory for thread_arg");
        return ENOMEM;
    }
    
    thread_arg->start_routine = start_routine;
    thread_arg->arg = arg;
    thread_arg->name = name;
    thread_arg->started = false;
    thread_arg->detached = detached;
    
    ret = pthread_mutex_init(&thread_arg->mutex, NULL);
    if (ret != 0) {
        LogError("Failed to initialize mutex: %s", strerror(ret));
        free(thread_arg);
        return ret;
    }
    
    ret = pthread_cond_init(&thread_arg->cond, NULL);
    if (ret != 0) {
        LogError("Failed to initialize condition variable: %s", strerror(ret));
        pthread_mutex_destroy(&thread_arg->mutex);
        free(thread_arg);
        return ret;
    }
    
    ret = pthread_create(thread, attr, _start_routine, thread_arg);
    if (ret != 0) {
        LogError("Failed to create thread: %d-%s", ret, strerror(ret));
        pthread_mutex_destroy(&thread_arg->mutex);
        pthread_cond_destroy(&thread_arg->cond);
        free(thread_arg);
        return ret;
    }

    // 初始化信号处理
    pthread_once(&once_control, setup_signal_handler);

    // 等待线程启动完成
    pthread_mutex_lock(&thread_arg->mutex);
    while (!thread_arg->started) {
        pthread_cond_wait(&thread_arg->cond, &thread_arg->mutex);
    }
    pthread_mutex_unlock(&thread_arg->mutex);

    // 销毁互斥锁和条件变量
    pthread_mutex_destroy(&thread_arg->mutex);
    pthread_cond_destroy(&thread_arg->cond);

    // 释放线程参数内存
    free(thread_arg);
    
    return 0;
}

static void* worker_thread(void* arg) 
{
    LogInfo("Tid: %ld, Worker thread started", syscall(SYS_gettid));
    // 线程工作...
    sleep(5);
    
    // 模拟崩溃
    int *p = NULL;
    *p = 42;  // 触发SIGSEGV
    
    return NULL;
}

static void* network_thread(void* arg) 
{
    int sleep_ms = (int)arg;
    // 网络处理...
    usleep(sleep_ms * 1000 * 1000);
    //LogInfo("Tid: %ld, sleep_ms: %d done", syscall(SYS_gettid), sleep_ms);
    return NULL;
}

int main(int argc, char *argv[])
{
    pthread_t worker_pid = 0, network_pid[5];
    THREAD_CREATE(&worker_pid, NULL, worker_thread, NULL);
#if 1
    for (int i = 0; i < 5; i++) {
        THREAD_CREATE(&network_pid[i], NULL, network_thread, (void *)(i + 1));
    }
#endif
    dump_all_thread_info();
    
    pthread_join(worker_pid, NULL);

#if 1
    for (int i = 0; i < 5; i++) {
        pthread_join(network_pid[i], NULL);
    }
#endif

    return 0;
}


