#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <stdbool.h>
#include <errno.h>
#include <string.h>
#include "condvar.h"

#define LogError(fmt, arg...) fprintf(stderr, "[%s-%d] " fmt "\n", __func__, __LINE__, ##arg)
#define LogInfo(fmt, arg...) fprintf(stderr, "[%s-%d] " fmt "\n", __func__, __LINE__, ##arg)

/**
 * @brief 条件变量上下文结构体
 */
typedef struct _cond_ctx {
    pthread_mutex_t mutex;          /**< 保护条件的互斥锁 */
    pthread_cond_t cond;            /**< 条件变量 */
    struct cond_ops ops; /**< 条件操作回调结构体 */
    volatile bool auto_reset;       /**< 是否自动重置条件 */
    volatile int waiters;           /**< 等待者计数 */
    volatile bool shutdown;         /**< 关闭标志, 用于通知等待线程退出等场景 */
    pthread_condattr_t cond_attr;   /**< 用于设置单调时钟 */
    
    /** 调试信息 */
    const char *name;               /**< 条件变量名称 */
} cond_ctx_t;

/**
 * @brief 初始化条件变量上下文
 * 
 * @param name 条件变量名称
 * @param auto_reset 是否自动重置条件
 * @param ops 条件操作回调结构体
 * 
 * @return cond_ctx_t* 成功返回条件变量上下文指针，失败返回NULL
 */
cond_ctx_t *cond_init(const char *name, bool auto_reset, struct cond_ops ops)
{
    int ret = 0;
    
    if (auto_reset && ops.reset == NULL) {
        LogError("auto_reset is true, but ops->reset is NULL");
        return NULL;
    }

    if (ops.check == NULL) {
        LogError("ops->check is NULL");
        return NULL;
    }

    if (ops.set == NULL) {
        LogError("ops->set is NULL");
        return NULL;
    }

    cond_ctx_t *ctx = malloc(sizeof(cond_ctx_t));
    if (ctx == NULL) {
        LogError("Failed to malloc cond_ctx_t");
        return NULL;
    }
    
    memset(ctx, 0, sizeof(cond_ctx_t));
    
    ret = pthread_mutex_init(&ctx->mutex, NULL);
    if (ret != 0) {
        LogError("Failed to init mutex: %s", strerror(ret));
        goto error;
    }
    
    // 优化：使用单调时钟，防止系统时间修改导致超时异常
    pthread_condattr_init(&ctx->cond_attr);
    pthread_condattr_setclock(&ctx->cond_attr, CLOCK_MONOTONIC);
    ret = pthread_cond_init(&ctx->cond, &ctx->cond_attr);
    if (ret != 0) {
        LogError("Failed to init cond: %s", strerror(ret));
        goto mutex_cleanup;
    }
    
    ctx->name = name;
    ctx->auto_reset = auto_reset;
    ctx->waiters = 0;
    ctx->ops = ops;
    ctx->shutdown = false;
    
    LogInfo("Condition context '%s' initialized successfully", name);
    return ctx;

mutex_cleanup:
    pthread_mutex_destroy(&ctx->mutex);
    pthread_condattr_destroy(&ctx->cond_attr);
error:
    return NULL;
}

/**
 * @brief 等待条件变量
 * 
 * @param ctx 条件变量上下文指针
 * @param timeout_ms 超时时间(毫秒)，-1表示无限等待
 * @param file 调用位置文件
 * @param func 调用位置函数
 * @param line 调用位置行号
 * @return int 成功返回0，超时返回ETIMEDOUT，错误返回其他错误码
 */
int cond_wait(cond_ctx_t *ctx, long timeout_ms, const char *file, const char *func, int line)
{
    int ret = 0;
    struct timespec ts;
    
    if (ctx == NULL) {
        LogError("Invalid parameter: ctx is NULL");
        return EINVAL;
    }
    
    ret = pthread_mutex_lock(&ctx->mutex);
    if (ret != 0) {
        LogError("Failed to lock mutex: %s", strerror(ret));
        return ret;
    }
    
    if (ctx->shutdown) {
        pthread_mutex_unlock(&ctx->mutex);
        LogError("Condition context '%s' is shutdown", ctx->name);
        return ECANCELED;
    }
    
    ctx->waiters++;
    
    LogInfo("Tid: %ld waiting on condition '%s' at %s:%s:%d", 
            syscall(SYS_gettid), ctx->name, file, func, line);
    
    while (!ctx->ops.check(ctx->ops.check_arg) && !ctx->shutdown) {
        if (timeout_ms >= 0) {
            clock_gettime(CLOCK_MONOTONIC, &ts);
            ts.tv_sec += timeout_ms / 1000;
            ts.tv_nsec += (timeout_ms % 1000) * 1000000;
            if (ts.tv_nsec >= 1000000000) {
                ts.tv_sec += 1;
                ts.tv_nsec -= 1000000000;
            }
            ret = pthread_cond_timedwait(&ctx->cond, &ctx->mutex, &ts);
        } else {
            ret = pthread_cond_wait(&ctx->cond, &ctx->mutex);
        }
        
        if (ret != 0) {
            LogError("Failed to wait condition: %d-%s", ret, strerror(ret));
            break;
        }
    }

    if (ctx->ops.check(ctx->ops.check_arg) && !ctx->shutdown && ctx->auto_reset) {
        ctx->ops.reset(ctx->ops.reset_arg);
    }
    
    ctx->waiters--;
    
    pthread_mutex_unlock(&ctx->mutex);
    
    if (ret == ETIMEDOUT) {
        LogInfo("Wait timeout on condition '%s'", ctx->name);
    } else if (ret == 0) {
        if (ctx->shutdown) {
            ret = ECANCELED;
            LogError("tid:%ld Wait canceled due to shutdown", syscall(SYS_gettid));
        } else {
            LogInfo("tid:%ld Wait satisfied on condition", syscall(SYS_gettid));
        }
    }
    
    return ret;
}

/**
 * @brief 通知一个等待线程
 * 
 * 在auto_reset为true情况下使用
 * 
 * @param ctx 条件变量上下文指针
 * @param set_arg 条件设置参数
 * @param file 调用位置文件
 * @param func 调用位置函数
 * @param line 调用位置行号
 * @return int 成功返回0，失败返回错误码
 */
int cond_signal(cond_ctx_t *ctx, void *set_arg, const char *file, const char *func, int line)
{
    int ret = 0;
    
    if (ctx == NULL) {
        LogError("Invalid parameter: ctx is NULL");
        return -EINVAL;
    }
    
    if (ctx->auto_reset) {
        LogError("cond_signal must be used when auto_reset is true");
        //return -EINVAL;
    }
    
    ret = pthread_mutex_lock(&ctx->mutex);
    if (ret != 0) {
        LogError("Failed to lock mutex: %s", strerror(ret));
        return ret;
    }
    
    LogInfo("tid:%ld Signaling one waiter on condition '%s' from %s:%s:%d", 
            syscall(SYS_gettid), ctx->name, file, func, line);
    
    ctx->ops.set(set_arg);
    
    ret = pthread_cond_signal(&ctx->cond);
    if (ret != 0) {
        LogError("Failed to signal condition: %s", strerror(ret));
        goto unlock;
    }
    
    LogInfo("Signaled %d waiters on condition '%s'", ctx->waiters, ctx->name);

unlock:
    pthread_mutex_unlock(&ctx->mutex);
    return ret;
}

/**
 * @brief 通知所有等待线程
 * 
 * 在auto_reset为false情况下使用
 * 
 * @param ctx 条件变量上下文指针
 * @param set_arg 条件设置参数
 * @param file 调用位置文件
 * @param func 调用位置函数
 * @param line 调用位置行号
 * @return int 成功返回0，失败返回错误码
 */
int cond_broadcast(cond_ctx_t *ctx, void *set_arg, const char *file, const char *func, int line)
{
    int ret = 0;
    
    if (ctx == NULL) {
        LogError("Invalid parameter: ctx is NULL");
        return -EINVAL;
    }
    
    if (!ctx->auto_reset) {
        //LogError("cond_broadcast must be used when auto_reset is false");
        return -EINVAL;
    }
    
    ret = pthread_mutex_lock(&ctx->mutex);
    if (ret != 0) {
        LogError("Failed to lock mutex: %s", strerror(ret));
        return ret;
    }
    
    LogInfo("Broadcasting to %d waiters on condition '%s' from %s:%s:%d", 
            ctx->waiters, ctx->name, file, func, line);
    
    ctx->ops.set(set_arg);
    
    ret = pthread_cond_broadcast(&ctx->cond);
    if (ret != 0) {
        LogError("Failed to broadcast condition: %s", strerror(ret));
        goto unlock;
    }
    
    LogInfo("Broadcast completed for %d waiters", ctx->waiters);

unlock:
    pthread_mutex_unlock(&ctx->mutex);
    return ret;
}

/**
 * @brief 关闭条件变量
 * 
 * @param ctx 条件变量上下文指针
 * @return int 成功返回0，失败返回错误码
 */
static int cond_shutdown(cond_ctx_t *ctx)
{
    int ret = 0;
    
    if (ctx == NULL) {
        LogError("Invalid parameter: ctx is NULL");
        return -EINVAL;
    }
    
    ret = pthread_mutex_lock(&ctx->mutex);
    if (ret != 0) {
        LogError("Failed to lock mutex: %s", strerror(ret));
        return ret;
    }
    
    if (ctx->shutdown) {
        LogInfo("Condition '%s' already shutdown", ctx->name);
        pthread_mutex_unlock(&ctx->mutex);
        return 0;
    }
    
    ctx->shutdown = true;
    
    if (ctx->waiters > 0) {
        LogInfo("Waking up %d waiters due to shutdown", ctx->waiters);
        ret = pthread_cond_broadcast(&ctx->cond);
        if (ret != 0) {
            LogError("Failed to broadcast during shutdown: %s", strerror(ret));
        }
    }
    
    pthread_mutex_unlock(&ctx->mutex);
    return ret;
}


/**
 * @brief 销毁条件变量上下文
 * 
 * @param ctx 条件变量上下文指针
 * @return int 成功返回0，失败返回错误码
 */
int cond_destroy(cond_ctx_t *ctx, const char *file, const char *func, int line)
{
    int ret = 0;
    int mutex_ret = 0;
    int cond_ret = 0;
    
    if (ctx == NULL) {
        LogError("Invalid parameter: ctx is NULL");
        return -EINVAL;
    }

    // 先关闭条件变量
    ret = cond_shutdown(ctx);
    if (ret != 0) {
        LogError("Failed to shutdown condition: %s", strerror(ret));
        return ret;
    }

    // 等待所有线程退出, 不能获取到mutex, 否则会死锁
    //pthread_mutex_lock(&ctx->mutex);
    while (ctx->waiters > 0) {
        usleep(100 * 1000); // 等待100ms
    }
    //pthread_mutex_unlock(&ctx->mutex);

    LogInfo("Destroying condition context '%s' from %s:%s:%d", ctx->name, file, func, line);
    
    mutex_ret = pthread_mutex_destroy(&ctx->mutex);
    if (mutex_ret != 0) {
        LogError("Failed to destroy mutex: %s", strerror(mutex_ret));
        ret = mutex_ret;
    }
    
    cond_ret = pthread_cond_destroy(&ctx->cond);
    if (cond_ret != 0) {
        LogError("Failed to destroy cond: %s", strerror(cond_ret));
        ret = cond_ret;
    }
    pthread_condattr_destroy(&ctx->cond_attr);
    
    free(ctx);
    ctx = NULL;
    
    return ret;
}